﻿using MyContactApp.Models;
using Microsoft.EntityFrameworkCore;

namespace MyContactApp.Data
{
    public class ContactsApiDbContext:DbContext
    {
        public ContactsApiDbContext(DbContextOptions options):base(options)
        {
            
        }
        public DbSet<Contact> Contacts { get; set; }

    }
}
